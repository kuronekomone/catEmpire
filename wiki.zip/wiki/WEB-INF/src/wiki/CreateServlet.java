package wiki;

import java.io.IOException;
import java.sql.SQLException;
import java.io.File;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.FileWriter;

//import org.apache.commons.fileupload.servlet.ServletFileUpload;
//import org.apache.commons.fileupload.disk.DiskFileItemFactory;
//import org.apache.commons.fileupload.FileItem;

import java.sql.*;


public class CreateServlet extends HttpServlet{
	
	public void doGet(HttpServletRequest req, HttpServletResponse res)
	throws ServletException,IOException{
		
		String name = req.getParameter("name");
		String content = req.getParameter("content");
		String image = req.getParameter("path");
		
		System.out.println("image= " +image);
		
		File imageurl = new File("C:\\Users\\15304007\\Pictures" + image);
		//File �I�u�W�F�N�g�� = new File(�t�@�C����);
		
		System.out.println("imageurl= " +imageurl);
		
		/*FileInputStream fis   = new FileInputStream(imageurl);
		InputStreamReader isr = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(isr);*/
		
		String path = imageurl.getPath();
		
		System.out.println("imageurl2= " +path);
		
		try{
			WikiPage wikiPage = new WikiPage();
			wikiPage.setName(name);
			wikiPage.setContent(content);
			wikiPage.setPath(path);
			
			WikiPageDAO.getInstance().insert(wikiPage);
			RequestUtils.setMessage(req, name + "���쐬���܂���");
			
			req.getRequestDispatcher("/refer").forward(req,res);
			
		}catch(SQLException e){
			throw new ServletException(e);
		}
	}
}